"""pi05_libero 推理冒烟测试：只用已下载的 pi05_libero 检查点和 LIBERO 格式的随机假观测。

不训练、不读取任何数据集。运行前必须设置 XLA_PYTHON_CLIENT_PREALLOCATE=false，
否则 JAX 会预先占用大部分显存，显存读数没有意义。
"""

import json
import os
import subprocess
import sys
import time

import numpy as np


def log(msg: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def gpu_used_mib() -> int:
    out = subprocess.run(
        ["nvidia-smi", "--query-gpu=memory.used", "--format=csv,noheader,nounits"],
        capture_output=True, text=True, check=True,
    ).stdout
    return int(out.strip().splitlines()[0])


if os.environ.get("XLA_PYTHON_CLIENT_PREALLOCATE") != "false":
    sys.exit("必须先设置 XLA_PYTHON_CLIENT_PREALLOCATE=false")

log(f"python={sys.executable}  VIRTUAL_ENV={os.environ.get('VIRTUAL_ENV', '<未设置>')}  "
    f"HF_HUB_OFFLINE={os.environ.get('HF_HUB_OFFLINE')}  XLA_PYTHON_CLIENT_PREALLOCATE=false")
baseline_mib = gpu_used_mib()
log(f"基线显存（启动 JAX 之前，包含 Windows 桌面等其他占用）：{baseline_mib} MiB")

import jax  # noqa: E402

from openpi.policies import libero_policy  # noqa: E402
from openpi.policies import policy_config  # noqa: E402
from openpi.shared import download  # noqa: E402
from openpi.training import config as _config  # noqa: E402

device = jax.devices()[0]
log(f"jax {jax.__version__}  设备 {device} ({device.device_kind})")


def mem_snapshot() -> dict:
    stats = device.memory_stats() or {}
    used = gpu_used_mib()
    return {
        "nvidia_smi_used_mib": used,
        "delta_vs_baseline_mib": used - baseline_mib,
        "jax_bytes_in_use_mib": round(stats.get("bytes_in_use", 0) / 2**20, 1),
        "jax_peak_bytes_in_use_mib": round(stats.get("peak_bytes_in_use", 0) / 2**20, 1),
        "jax_bytes_limit_mib": round(stats.get("bytes_limit", 0) / 2**20, 1),
    }


config = _config.get_config("pi05_libero")
checkpoint_dir = download.maybe_download("gs://openpi-assets/checkpoints/pi05_libero")
log(f"checkpoint_dir = {checkpoint_dir}")
log(f"模型配置：pi05={config.model.pi05} action_horizon={config.model.action_horizon} "
    f"action_dim={config.model.action_dim} max_token_len={config.model.max_token_len}")

t = time.perf_counter()
policy = policy_config.create_trained_policy(config, checkpoint_dir)
load_s = time.perf_counter() - t
mem_load = mem_snapshot()
log(f"加载用时 {load_s:.1f} s；显存 {mem_load}")

np.random.seed(0)
example = libero_policy.make_libero_example()
log("假观测：" + json.dumps(
    {k: (v if k == "prompt" else {"shape": list(np.shape(v)), "dtype": str(np.asarray(v).dtype)})
     for k, v in example.items()}, ensure_ascii=False))

t = time.perf_counter()
out = policy.infer(example)
first_s = time.perf_counter() - t
mem_first = mem_snapshot()
first = np.asarray(out["actions"])
log(f"第一次推理（含 JIT 编译）{first_s:.2f} s；输出键 {sorted(out)}；actions 形状 {first.shape} dtype {first.dtype}；"
    f"全部有限 {bool(np.isfinite(first).all())}；显存 {mem_first}")

all_actions = [first]
wall_ms, internal_ms = [], []
for i in range(10):
    t = time.perf_counter()
    o = policy.infer(example)
    wall_ms.append((time.perf_counter() - t) * 1000)
    internal_ms.append(o["policy_timing"]["infer_ms"])
    all_actions.append(np.asarray(o["actions"]))
    log(f"  第 {i + 2} 次：{wall_ms[-1]:.1f} ms（openpi 内部计时 {internal_ms[-1]:.1f} ms）")
mem_10 = mem_snapshot()

stack = np.stack(all_actions)  # (11, horizon, 7)
summary = {
    "checkpoint_dir": str(checkpoint_dir),
    "load_seconds": round(load_s, 2),
    "actions_shape": list(first.shape),
    "actions_dtype": str(first.dtype),
    "all_shapes_identical": len({a.shape for a in all_actions}) == 1,
    "all_finite_all_11_calls": bool(np.isfinite(stack).all()),
    "range_all_calls": [float(stack.min()), float(stack.max())],
    "per_dim_min": [round(float(x), 4) for x in stack.min(axis=(0, 1))],
    "per_dim_max": [round(float(x), 4) for x in stack.max(axis=(0, 1))],
    "first_chunk_first_step": [round(float(x), 4) for x in first[0]],
    "first_infer_seconds_incl_jit": round(first_s, 2),
    "next10_wall_ms_mean": round(float(np.mean(wall_ms)), 1),
    "next10_wall_ms_std": round(float(np.std(wall_ms)), 1),
    "next10_wall_ms_min_max": [round(min(wall_ms), 1), round(max(wall_ms), 1)],
    "next10_openpi_internal_ms_mean": round(float(np.mean(internal_ms)), 1),
    "baseline_gpu_mib": baseline_mib,
    "mem_after_load": mem_load,
    "mem_after_first_infer": mem_first,
    "mem_after_11_infers": mem_10,
}
print("SUMMARY_JSON " + json.dumps(summary, ensure_ascii=False), flush=True)
