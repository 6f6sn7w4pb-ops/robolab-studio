PR 标题（复制下面一行）：

Add lab master plan and zero-shot report; update handoff for 2026-11-20

PR 描述（复制下面全部）：

## Summary

- **docs/LAB_MASTER_PLAN.md (new)**: full overview for new conversations: research question and the generalized task (named parts, object sources A/B/C, four held-out levels, English-only instructions), timeline, all modeling dimensions of the current floor layout and of the measured lab layout, camera placement (fixed in simulation, real mounts 3D-printed), decisions, differences from earlier plans, staged next tasks with completion criteria, new generator requirements, LoRA config draft, model list, storage budget and the work-disk procedure.
- **docs/LAB_ZEROSHOT_REPORT.md (new)**: `pi05_libero` zero-shot evaluation on the 240 extended test scenes: success 36/240 = 15.0% [11.0, 20.1], 0 policy errors, 2x2 breakdown, failure analysis (part words largely ignored; 43 episodes reached for the obstacle), gripper clipping, latency, interface checks, sampling-noise source, reproduction commands.
- **docs/LAB_STAGE_HANDOFF.md**: sections 3-10 updated with the 2026-11-20 decisions (5,000 episodes, lab layout for all new data and tests, single machine, work disk), step 1 marked done, next steps reordered, new notes.
- **docs/NEXT_CHAT_HANDOFF.md**: section 23 for 2026-11-20.

Documentation only; no code or requirements change. The openpi bridge code described here is on the separate branch `pi05-bridge`, which will get its own PR.

## Test plan

- [x] All relative links in the new and updated documents point to existing files
- [x] No personal information in the documents
- [ ] GitHub "Lightweight checks" pass on this branch

🤖 Generated with [Claude Code](https://claude.com/claude-code)
