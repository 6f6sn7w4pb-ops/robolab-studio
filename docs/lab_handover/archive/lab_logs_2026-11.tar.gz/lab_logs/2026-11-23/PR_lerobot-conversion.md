PR 标题（复制下面一行）：

Add LeRobot converter, openpi LoRA runner and step 2-4 documentation

PR 描述（复制下面全部）：

## Summary

- **scripts/convert_p4_to_lerobot.py**: converts the P4 HDF5 training view to a LeRobot v2.1 dataset (the version pinned by openpi), run with openpi's interpreter. Baseline fields `image`, `wrist_image` (lossless PNG, `dtype: image`, no video), `state`, `actions`, `task`; fps 20; openpi LIBERO image orientation. `verify` is an independent code path that requires every image to equal the HDF5 image flipped horizontally, pixel for pixel; `append-test` and `compare` check that appending and re-converting are byte-identical. `EXTRA_FIELDS` is the hook for later contact labels.
- **scripts/openpi_robolab.py**: our pi0.5 LoRA `TrainConfig`, registered into openpi's `_CONFIGS_DICT` at run time (openpi's source is not edited), then openpi's own `compute_norm_stats.py` / `train.py` `main`; `train --measure` records compile and per-step time, JAX `peak_bytes_in_use`, GPU utilization, host memory and checkpoint size.
- **Docs**: new `docs/LAB_LORA_PROBE.md`; `LAB_STAGE_HANDOFF.md`, `P4_DATASET_FORMAT.md`, `LAB_MASTER_PLAN.md` and `NEXT_CHAT_HANDOFF.md` updated for 2026-11-23.

Results on the lab machine: 120 episodes / 26,640 frames, all 53,280 images pixel-identical, 2.72 GB; appending is byte-identical to a one-pass conversion. LoRA probe (300 steps): batch 32 at 5.43 s/step and 23.3 GiB peak; batch 64 at 12.0 s/step and 31.5 GiB peak (needs memory fraction 0.9); GPU utilization about 100%; checkpoint 9.6 GB; loss 0.08 to 0.019.

The dataset `robolab/p4d_v1_train` records code commit `0b6a173`; please merge with **"Create a merge commit"** so that commit stays in `main`'s history.

## Test plan

- [x] `bash scripts/test_engine.sh`: 112 tests pass, 3 GUI modules skipped by design
- [x] `convert_p4_to_lerobot.py verify`: 120 episodes / 26,640 frames, 53,280 images pixel-identical
- [x] `convert_p4_to_lerobot.py append-test` and `compare`: byte-identical
- [x] Two 300-step LoRA runs completed (`docs/LAB_LORA_PROBE.md`)
- [ ] GitHub Lightweight checks pass

🤖 Generated with [Claude Code](https://claude.com/claude-code)
