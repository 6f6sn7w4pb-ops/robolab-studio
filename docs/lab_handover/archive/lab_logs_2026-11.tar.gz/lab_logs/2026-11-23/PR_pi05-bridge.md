PR 标题（复制下面一行）：

Add openpi (pi0.5) bridge service and pi05 evaluation adapter

PR 描述（复制下面全部）：

## Summary

- **scripts/serve_openpi_bridge.py**: RoboLab VLA bridge protocol v1 service that runs in openpi's own environment (Python 3.11 + JAX). Loads a local openpi LIBERO checkpoint (never downloads), warms up once, converts `robolab.observation.v1` to openpi LIBERO inputs (canonical images flipped horizontally, which equals the openpi client's 180-degree rotation of raw robosuite frames), serializes inference with a lock, clips actions less than 0.05 outside [-1, 1] and reports the count and maximum excess, and returns an error without clipping for anything further out. Endpoints `/health`, `/stats`, `/predict`; optional per-request JSONL log.
- **robolab/policy.py**: `OpenpiAdapter`, registered as `pi05`. Refuses test backends; `real_model` / `model_loaded` reflect what the service reports, so evaluations are marked as real VLA only for a loaded model. `OpenVLAOFTAdapter` and `MockPolicy` are unchanged.
- **robolab/locales/en.json**: English label for the new adapter.
- **tests/test_openpi_bridge.py**: 14 GPU-free tests with a fake policy (protocol fields, image flip, clipping rule, serialized inference, HttpPolicy round trip, adapter behaviour).
- Merge commit `78d1434` brings `main` (docs PRs #8-#10, install fixes) into the branch; no overlapping files.

This is the exact code (`37b4e4c`) recorded by the zero-shot evaluation in `docs/LAB_ZEROSHOT_REPORT.md`; please merge with **"Create a merge commit"** so that commit stays in `main`'s history. No behaviour change beyond the original commit. Fixed sampling noise (seeded from observation content) will come in a separate PR.

## Test plan

- [x] `bash scripts/test_engine.sh`: 112 tests pass (98 existing + 14 bridge), 3 GUI modules skipped by design
- [x] GUI venv: `test_i18n`, `test_p4_dataset_view`, `test_p5_eval_view` pass; `launch.sh --smoke` passes
- [x] Zero-shot evaluation with this code: 240/240 episodes, 0 policy errors (`docs/LAB_ZEROSHOT_REPORT.md`)
- [ ] GitHub Lightweight checks pass

🤖 Generated with [Claude Code](https://claude.com/claude-code)
